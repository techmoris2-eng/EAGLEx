package in.eaglex.agent

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

private val client=OkHttpClient()
private suspend fun call(path:String,token:String?=null,method:String="POST",json:String="{}"):String=withContext(Dispatchers.IO){ val b=Request.Builder().url(BuildConfig.API_BASE_URL+path.trimStart('/')).post(json.toRequestBody("application/json".toMediaType())); if(token!=null)b.addHeader("Authorization","Bearer $token"); if(method=="GET")b.get(); val r=client.newCall(b.build()).execute(); val s=r.body?.string().orEmpty(); if(!r.isSuccessful) error("HTTP ${r.code}: $s"); s }

class MainActivity:ComponentActivity(){
    private var permissionResult by mutableStateOf("No permissions requested")
    private val contactsPermission=registerForActivityResult(ActivityResultContracts.RequestPermission()){ permissionResult=if(it) "Contacts permission granted" else "Contacts permission denied" }
    private val photoPicker=registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()){ uris-> permissionResult="User selected ${uris.size} media item(s). No media is uploaded by this demo." }
    private val screenConsent=registerForActivityResult(ActivityResultContracts.StartActivityForResult()){ r-> permissionResult=if(r.resultCode==Activity.RESULT_OK) "Screen capture approved for this session" else "Screen capture declined" }
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); setContent { MaterialTheme(colorScheme=darkColorScheme(primary=androidx.compose.ui.graphics.Color(0xFF168BFF))) { AgentApp(permissionResult,{contactsPermission.launch(Manifest.permission.READ_CONTACTS)},{photoPicker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))},{ val m=getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager; screenConsent.launch(m.createScreenCaptureIntent()) }) } } }
}

@Composable fun AgentApp(status:String,onContacts:()->Unit,onPhotos:()->Unit,onScreen:()->Unit){
    var code by remember { mutableStateOf("") }; var token by remember { mutableStateOf<String?>(null) }; var info by remember { mutableStateOf("This app is visible to the device user. Pairing requires a one-time code and your confirmation.") }; var approved by remember { mutableStateOf(false) }; val scope=rememberCoroutineScope()
    Surface(Modifier.fillMaxSize()){ Column(Modifier.fillMaxSize().padding(22.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        Text("EAGLEx | Agent",style=MaterialTheme.typography.headlineMedium); Text("Device companion · Consent required",color=MaterialTheme.colorScheme.primary)
        Text(info,style=MaterialTheme.typography.bodyMedium)
        if(token==null){ OutlinedTextField(code,{code=it},label={Text("One-time pairing code")},modifier=Modifier.fillMaxWidth()); Row { Checkbox(approved,{approved=it}); Text("I approve enrolling this device with the administrator shown in the pairing flow.",modifier=Modifier.padding(top=12.dp)) }; Button(enabled=approved && code.isNotBlank(),onClick={ scope.launch { try { val j=JSONObject(call("v1/enroll",json=JSONObject().put("code",code).put("name",Build.MODEL).put("model",Build.MANUFACTURER+" "+Build.MODEL).put("androidVersion",Build.VERSION.RELEASE).put("userConfirmed",true).toString())); token=j.getString("token"); info="Device enrolled. You can now request approved support features." } catch(e:Exception){ info=e.message ?: "Enrollment failed" } } }){Text("Confirm and enroll") } }
        else { Text("Device is paired."); Button(onClick=onContacts){Text("Request contacts permission")}; Button(onClick=onPhotos){Text("Choose photos or videos")}; Button(onClick=onScreen){Text("Request screen-sharing consent")}; OutlinedButton(onClick={token=null;info="Disconnected. The device credential should also be revoked from Admin."}){Text("Disconnect")} }
        Text("Permission/session status: $status",style=MaterialTheme.typography.bodySmall)
        Text("The Android system displays its own consent UI for screen capture. Selecting media uses the system Photo Picker.",style=MaterialTheme.typography.bodySmall)
    } }
}
