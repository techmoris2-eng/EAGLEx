import bcrypt from 'bcryptjs'; import {pool} from './db.js';
const [email,password]=process.argv.slice(2); if(!email||!password||password.length<12){console.error("Usage: npm run admin:create -- email password (12+ chars)");process.exit(1)}
await pool.query('INSERT INTO admins(email,password_hash) VALUES($1,$2) ON CONFLICT(email) DO NOTHING',[email.toLowerCase(),await bcrypt.hash(password,12)]); console.log('Admin created if email was new'); await pool.end();
