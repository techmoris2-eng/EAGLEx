import {pool} from './db.js';
await pool.query(`CREATE TABLE IF NOT EXISTS admins(id UUID PRIMARY KEY DEFAULT gen_random_uuid(),email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'admin',created_at TIMESTAMPTZ DEFAULT now());
CREATE TABLE IF NOT EXISTS devices(id UUID PRIMARY KEY DEFAULT gen_random_uuid(),name TEXT NOT NULL,model TEXT,android_version TEXT,token_version INT NOT NULL DEFAULT 1,revoked BOOLEAN NOT NULL DEFAULT false,last_seen TIMESTAMPTZ,created_at TIMESTAMPTZ DEFAULT now());
CREATE TABLE IF NOT EXISTS pairing_codes(code_hash TEXT PRIMARY KEY,admin_id UUID REFERENCES admins(id),expires_at TIMESTAMPTZ NOT NULL,consumed_at TIMESTAMPTZ);
CREATE TABLE IF NOT EXISTS sessions(id UUID PRIMARY KEY DEFAULT gen_random_uuid(),device_id UUID REFERENCES devices(id),admin_id UUID REFERENCES admins(id),started_at TIMESTAMPTZ DEFAULT now(),ended_at TIMESTAMPTZ);
CREATE TABLE IF NOT EXISTS audit(id BIGSERIAL PRIMARY KEY,actor_type TEXT NOT NULL,actor_id TEXT NOT NULL,action TEXT NOT NULL,detail JSONB NOT NULL DEFAULT '{}',created_at TIMESTAMPTZ DEFAULT now());`);
console.log('Database schema ready'); await pool.end();
