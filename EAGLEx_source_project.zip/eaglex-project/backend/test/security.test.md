# Required security acceptance tests

- Login rejects wrong passwords and unknown accounts; passwords are stored as bcrypt hashes.
- Pairing code is single-use, expires after 300 seconds, and is never stored in plaintext.
- Enrollment rejects missing `userConfirmed: true`.
- Device token cannot call admin routes; admin token cannot call device heartbeat.
- Revoked device token fails on the next request, including tokens issued before revocation.
- Session start rejects unknown/revoked devices; only the creating admin can end its session.
- Invalid JSON, oversized bodies and malformed IDs return errors without leaking stack traces.
- All login, enrollment, pairing, revocation and session events appear in the audit table.
