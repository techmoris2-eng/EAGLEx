# EAGLEx privacy notice (deployment template)

EAGLEx is a device-management companion. The Agent identifies itself and requires the device user's explicit action to enroll. The administrator can see the device name/model, Android version and last-seen timestamp. Contacts, media and screen content are not uploaded by this starter. Contacts require Android runtime permission; media selection uses Android Photo Picker; screen capture requires Android's system MediaProjection approval for each session. The user can stop an active session and disconnect the Agent.

Before production, the operator must publish a controller identity, purpose, data categories, recipients, retention period, deletion/contact process, lawful basis and support contact. Do not enable collection until a separate informed consent and data-export flow is implemented.
