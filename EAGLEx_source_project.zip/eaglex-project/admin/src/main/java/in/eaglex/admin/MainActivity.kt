package in.eaglex.admin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import org.json.JSONArray
import java.io.IOException

private val http = OkHttpClient()
private suspend fun api(path:String, token:String?=null, method:String="GET", body:String?=null):String = withContext(Dispatchers.IO) {
    val b = Request.Builder().url(BuildConfig.API_BASE_URL + path.trimStart('/'))
    if(token!=null) b.addHeader("Authorization","Bearer $token")
    if(method=="POST" || method=="DELETE") b.method(method,(body ?: "{}").toRequestBody("application/json".toMediaType()))
    val r=http.newCall(b.build()).execute(); val s=r.body?.string().orEmpty(); if(!r.isSuccessful) error("HTTP ${r.code}: $s"); s
}

class MainActivity:ComponentActivity(){ override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState); setContent { MaterialTheme(colorScheme=darkColorScheme(primary=androidx.compose.ui.graphics.Color(0xFF168BFF), background=androidx.compose.ui.graphics.Color(0xFF050914), surface=androidx.compose.ui.graphics.Color(0xFF101B2D))) { AdminApp() } } } }

@Composable fun AdminApp(){
    var email by remember { mutableStateOf("admin@example.com") }; var password by remember { mutableStateOf("") }; var token by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf("Sign in to manage enrolled devices.") }; var code by remember { mutableStateOf("") }; var devices by remember { mutableStateOf(listOf<Triple<String,String,String>>()) }; var busy by remember { mutableStateOf(false) }; val scope=rememberCoroutineScope()
    suspend fun refresh(t:String){ val j=JSONObject(api("v1/devices",t)); val a=j.getJSONArray("devices"); devices=(0 until a.length()).map { val d=a.getJSONObject(it); Triple(d.getString("id"),d.optString("name","Android device"),d.optString("last_seen","Never seen")) } }
    Surface(Modifier.fillMaxSize()) { Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically){ Image(painterResource(R.drawable.eaglex_logo),null,Modifier.size(64.dp)); Spacer(Modifier.width(12.dp)); Column { Text("EAGLEx | Admin",style=MaterialTheme.typography.headlineSmall); Text("SECURE DEVICE MANAGEMENT",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.primary) } }
        Text(message,style=MaterialTheme.typography.bodySmall)
        if(token==null){ OutlinedTextField(email,{email=it},label={Text("Admin email")},modifier=Modifier.fillMaxWidth()); OutlinedTextField(password,{password=it},label={Text("Password")},modifier=Modifier.fillMaxWidth()); Button(enabled=!busy,onClick={busy=true; message="Signing in…"}) { Text("Sign in") }; LaunchedEffect(busy){ if(busy){ try { val j=JSONObject(api("v1/auth/login",method="POST",body=JSONObject().put("email",email).put("password",password).toString())); token=j.getString("token"); refresh(token!!); message="Authenticated. Pair devices using a one-time code." } catch(e:Exception){message=e.message ?: "Sign-in failed"} finally {busy=false} } } }
        } else {
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ Button(onClick={busy=true}){Text("Generate pairing code")}; OutlinedButton(onClick={busy=true}){Text("Refresh")}; TextButton(onClick={token=null}){Text("Sign out")} }
            LaunchedEffect(busy){ if(busy){ try { if(code.isEmpty()){ val j=JSONObject(api("v1/pairing-codes",token,"POST")); code=j.getString("code"); message="Share this code with the Agent user: $code (expires in 5 minutes)." } else { refresh(token!!); message="Device inventory updated." } } catch(e:Exception){message=e.message ?: "Request failed"} finally {busy=false} } }
            if(code.isNotEmpty()){ Card { Column(Modifier.padding(16.dp)){ Text("ONE-TIME ENROLLMENT CODE",style=MaterialTheme.typography.labelMedium); Text(code,style=MaterialTheme.typography.headlineMedium,color=MaterialTheme.colorScheme.primary); Text("Expires in five minutes. Agent must confirm enrollment on-device.") } } }
            Text("Enrolled devices",style=MaterialTheme.typography.titleLarge)
            LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){ items(devices){ d -> Card { Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){ Column(Modifier.weight(1f)){Text(d.second); Text("ID ${d.first.take(8)} · ${d.third}",style=MaterialTheme.typography.bodySmall)}; TextButton(onClick={scope.launch { try { api("v1/devices/${d.first}",token,"DELETE"); refresh(token!!); message="Device revoked." } catch(e:Exception){ message=e.message ?: "Revocation failed" } }){Text("Revoke")} } } } }
            Text("All enrollment and revocation operations are recorded in the backend audit log.",style=MaterialTheme.typography.bodySmall)
        }
    } }
}
