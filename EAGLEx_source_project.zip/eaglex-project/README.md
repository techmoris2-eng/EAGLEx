# EAGLEx — Android device management starter

This repository contains two Android applications and a Node.js API:

- `admin/` — operator dashboard for pairing, viewing, revoking and auditing enrolled test devices.
- `agent/` — visible companion app with explicit pairing, device status, permission explanations and session controls.
- `backend/` — Express API with short-lived JWTs, one-time pairing codes, per-device credentials, role checks and audit events.

## Requirements

- Android Studio Ladybug or newer; JDK 17; Android SDK 35.
- Node.js 20+ and PostgreSQL 15+.
- Set `API_BASE_URL` in each app's `BuildConfig` to your HTTPS API URL. For a local emulator use `http://10.0.2.2:3000/`; cleartext is enabled only in the debug manifest. Production must use HTTPS.

## Backend setup

```bash
cd backend
cp .env.example .env
# Create the PostgreSQL database named in DATABASE_URL, then:
npm install
npm run db:init
npm run admin:create -- admin@example.com 'ReplaceThisPassword!'
npm start
```

Set a long random `JWT_SECRET` (32+ bytes). Put the API behind TLS in production. Never commit `.env`.

## Android setup

Open this directory in Android Studio, allow Gradle sync, then run either `admin` or `agent` on Android 8.0+ devices. The app IDs are `in.eaglex.admin` and `in.eaglex.agent`. The supplied blue emblem is installed as the Admin launcher icon and displayed in its dashboard.

For a first pairing: sign in to Admin with the seeded operator account; create a one-time code; open Agent and enter the code; the Agent asks for confirmation before enrollment. The device then appears in Admin. Revoke it from the Admin device detail screen to invalidate its device credential.

## Current MVP functionality

- Admin login, one-time pairing-code generation, device list, revoke action and audit event list.
- Agent pairing, device metadata heartbeat, visible active-session notification, stop control and local permission explanations.
- Backend password hashing, role-based middleware, short-lived access tokens, per-device JWTs, one-time code expiry/consumption, device revocation and audit records.
- Agent exposes explicit Android permission flows for contacts and the system Photo Picker. The Agent includes a MediaProjection consent-launch example; actual capture, foreground-service lifecycle and streaming transport are not implemented in this starter. Lock is intentionally not exposed in this starter; a production managed-device deployment must provision Device Owner and implement an explicit DevicePolicyManager policy.

## Production hardening checklist

1. Replace the demo in-memory Android token handling with encrypted persistence backed by Android Keystore; implement refresh-token rotation and certificate pinning only with a rotation plan.
2. Add organization provisioning, MFA, account recovery, rate limiting at the gateway, CSRF protection for any browser UI, structured monitoring and backup/restore.
3. Add explicit data export UX, retention controls, consent receipts and server-side authorization for each data type before implementing contact/media transfer.
4. Add a reviewed MediaProjection foreground-service implementation for the target Android release; Android requires user approval for each capture session. This starter demonstrates the consent boundary and session lifecycle, not a covert capture pipeline.
5. Run dependency, static-analysis and penetration tests; configure Play policy disclosures and privacy policy before distribution.

## API overview

- `POST /v1/auth/login` — admin login.
- `POST /v1/pairing-codes` — admin creates a one-time code (5-minute expiry).
- `POST /v1/enroll` — Agent redeems code after on-device confirmation; returns device token.
- `POST /v1/device/heartbeat` — device-authenticated metadata update.
- `GET /v1/devices` — admin device inventory.
- `DELETE /v1/devices/:id` — revoke device credential.
- `POST /v1/sessions` and `DELETE /v1/sessions/:id` — start/end an auditable support session.
- `GET /v1/audit` — admin audit events.

## Security model

A pairing code is single-use and expires after five minutes. Admin tokens have the `admin` role; Agent tokens are bound to one device ID. Revocation is checked on every device-authenticated API call. All sensitive actions are audited. Do not expose the API directly to the public internet without TLS, a reverse proxy, rate limiting and operational monitoring.
